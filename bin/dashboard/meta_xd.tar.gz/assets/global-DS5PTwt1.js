import{a5 as a,a_ as m}from"./index-DSRoS9Rj.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
