import{W as a,b4 as m}from"./index-CxY9iUr8.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
