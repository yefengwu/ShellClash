import{f as t,bB as r}from"./index-DdEpW1wR.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
